package com.example.dailyfeed;

import com.example.dailyfeed.Models.NewsHeadLines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadLines headLines);
}
